  <section class="header" id="header" style="background-image: url('img/bg/Bagkround.jpg');">
    <div class="container">
      <div class="row header__row">
        <div class="col">
          <div class="header__title">
            ОТ НАБРОСКА<br>
            К ГОТОВОМУ ИЗДЕЛИЮ
          </div>
          <div class="header__btn-wrap">
            <a href="portfolio.php" class="button">ПОСМОТРЕТЬ ПРОЕКТЫ</a>
          </div>
        </div>
      </div>
    </div>
  </section>